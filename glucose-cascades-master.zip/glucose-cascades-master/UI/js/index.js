function deleteModeSelect(mode) {
    document.getElementById("page").removeChild(document.getElementById("mode-select"));
    return;
}

function addStartImage(){
    document.getElementById("start").src("/images/cat.jpg");
}
