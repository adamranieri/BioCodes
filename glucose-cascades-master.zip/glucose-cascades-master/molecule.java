package glucose_cascade;

public class molecule {
	
	String name;
	//store an image
	
	
	public molecule(String name){ // hopefully add an image parameter
		this.name = name;
		
		
	}
	
	public String getName(){
		return this.name;
	}
	
	

}
